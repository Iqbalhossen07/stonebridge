<header class="fixed inset-x-0 top-0 z-50">
    <div class="hidden md:block text-sm py-2 bg-primary text-white">
        <div class="container mx-auto px-6 flex items-center justify-between">
            <div class="flex items-center gap-6">
                <a href="mailto:info@stonebridgelegal.co.uk" class="flex items-center gap-2 hover:opacity-80 transition-opacity">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                    <span>info@stonebridgelegal.co.uk</span>
                </a>
                <a href="tel:+447988138221" class="flex items-center gap-2 hover:opacity-80 transition-opacity">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                    <span>+447988138221</span>
                </a>
            </div>
            <div class="flex items-center gap-4">
                <a href="#register" class="px-3 py-1 text-xs border border-white/50 rounded-full hover:bg-white/10 transition-colors">Book Appointment</a>
            </div>
        </div>
    </div>

    <div id="navWrap" class="transition-all bg-white/70 backdrop-blur-xl border-b shadow-soft-1">
        <div class="h-0.5 bg-primary/30" id="progressBar" style="width:0%"></div>
        <nav class="container mx-auto px-6 flex items-center justify-between py-4">
            <a href="index.php" class="inline-flex items-center gap-2">
                <img class="w-24" src="img/logo.png" alt="Stonebridge Legal Logo">
            </a>
            
            <ul class="hidden md:flex items-center gap-8 font-semibold">
                <li><a href="index.php" class="text-sm tracking-wide hover:text-primary  transition-colors">Home</a></li>
            <li class="relative group">
    <a href="about.php" class="text-sm tracking-wide hover:text-primary transition-colors flex items-center gap-1">
        About
        <svg class="h-4 w-4 transition-transform duration-300 group-hover:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
    </a>
    <div class="absolute top-full left-0 w-48 bg-white shadow-soft-2 rounded-lg border mt-2 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-10">
        <a href="about.php" class="block px-4 py-2 text-sm text-slate-700 hover:bg-primary/5 hover:text-primary">About Us</a>
        <a href="team.php" class="block px-4 py-2 text-sm text-slate-700 hover:bg-primary/5 hover:text-primary">Our Team</a>
    </div>
</li>
              <li class="relative group">
            <a href="services.html" class="text-sm tracking-wide hover:text-primary transition-colors flex items-center gap-1">
                Services
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
            </a>
            <div class="mega-menu absolute top-full left-1/2 -translate-x-1/2 w-screen max-w-7xl bg-white shadow-soft-2 rounded-lg border mt-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div class="p-8 grid grid-cols-5 gap-8">
                    
                    <div class="space-y-6">
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Sponsorship Licence</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Sponsor Licence Application</a></li>
                                <li><a href="#" class="mega-menu-link">Sponsor Licence Renewal</a></li>
                                <li><a href="#" class="mega-menu-link">Sponsor Licence Suspension</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Global Business Mobility</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Graduate Trainee Visa</a></li>
                                <li><a href="#" class="mega-menu-link">UK Expansion Worker visa</a></li>
                                <li><a href="#" class="mega-menu-link">Specialist Worker Visa</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">UKVI Compliant HR Software</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Compliant HR Software</a></li>
                                <li><a href="#" class="mega-menu-link">Sponsorship Duties</a></li>
                                <li><a href="#" class="mega-menu-link">HO Compliance Audit in UK</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="space-y-6">
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Immigration Compliance</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Civil Penalty</a></li>
                                <li><a href="#" class="mega-menu-link">HO Compliance Visit</a></li>
                                <li><a href="#" class="mega-menu-link">Right to Work Check</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Standard Visitor Visa</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Tourist Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Business Visit</a></li>
                                <li><a href="#" class="mega-menu-link">UK Fiancé Visa</a></li>
                            </ul>
                        </div>
                         <div>
                            <h4 class="font-semibold text-slate-800 mb-3">EU Settlement Scheme</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">EU Pre-Settled Status</a></li>
                                <li><a href="#" class="mega-menu-link">EU Settled Status</a></li>
                                <li><a href="#" class="mega-menu-link">EU Family Permit</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="space-y-6">
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Skilled Worker Visas</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Skilled Worker Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Minister of Religion Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Health Care Visa</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Study Visas</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Student Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Child Student Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Graduate Visa</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">UK Settlement Scheme</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">20 Year Private Life Route</a></li>
                                <li><a href="#" class="mega-menu-link">ILR (5 year route)</a></li>
                                <li><a href="#" class="mega-menu-link">ILR (10 year route)</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="space-y-6">
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Temporary (Tier 5) Visas</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Religious Worker Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Creative Worker Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Charity Worker Visa</a></li>
                            </ul>
                        </div>
                         <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Business Visas</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Self-Sponsorship in UK</a></li>
                                <li><a href="#" class="mega-menu-link">Innovator Founder Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Turkish Businessperson Visa</a></li>
                            </ul>
                        </div>
                         <div>
                            <h4 class="font-semibold text-slate-800 mb-3">British Citizenship</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Naturalisation</a></li>
                                <li><a href="#" class="mega-menu-link">BNO Status</a></li>
                                <li><a href="#" class="mega-menu-link">Registration</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="space-y-6">
                        <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Partner and family Visas</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Spouse Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Dependent Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Unmarried Partner Visa</a></li>
                            </ul>
                        </div>
                         <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Scale Up Visa</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Scale-up Visa</a></li>
                                <li><a href="#" class="mega-menu-link">Scale-up Sponsor Licence</a></li>
                                <li><a href="#" class="mega-menu-link">Scale up Business</a></li>
                            </ul>
                        </div>
                         <div>
                            <h4 class="font-semibold text-slate-800 mb-3">Immigration Appeals</h4>
                            <ul class="space-y-2 text-sm">
                                <li><a href="#" class="mega-menu-link">Judicial Review</a></li>
                                <li><a href="#" class="mega-menu-link">Administrative Review</a></li>
                                <li><a href="#" class="mega-menu-link">Appeal To The Tribunal</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </li>
            <li><a href="psw.php" class="text-sm tracking-wide hover:text-primary transition-colors">PSW</a></li>
            <li><a href="asylum.php" class="text-sm tracking-wide hover:text-primary transition-colors">Asylum</a></li>
            <li><a href="sponsor-checker.php" class="text-sm tracking-wide hover:text-primary transition-colors">Sponsor Checker</a></li>

            <li><a href="gallery.php" class="text-sm tracking-wide hover:text-primary transition-colors">Gallery</a></li>
            <li><a href="events.php" class="text-sm tracking-wide hover:text-primary transition-colors">Events</a></li>
            <li><a href="blog.php" class="text-sm tracking-wide hover:text-primary transition-colors">Blog</a></li>
            <li><a href="contact.php" class="text-sm tracking-wide hover:text-primary transition-colors">Contact</a></li>
                </ul>

            <a href="mailto:info@stonebridgelegal.co.uk" class="md:hidden p-2 rounded-md border border-slate-200 text-primary hover:bg-slate-100" aria-label="Email Us">
                <svg class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.902L12 11.625l-7.189-3.68a2.25 2.25 0 01-1.07-1.902V6.75" /></svg>
            </a>
        </nav>
    </div>

    <div class="md:hidden fixed bottom-0 left-0 right-0 bg-primary text-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)] z-50">
        <div class="grid grid-cols-4">
            <a href="tel:+447988138221" class="flex flex-col items-center justify-center p-3 text-center transition-colors hover:bg-white/10">
                <svg class="h-6 w-6 mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.396a2.25 2.25 0 00-1.026-1.956l-2.243-.996a2.25 2.25 0 00-2.43.513l-.645 1.076a11.022 11.022 0 01-5.222-5.222l1.076-.645a2.25 2.25 0 00.513-2.43L6.75 4.275a2.25 2.25 0 00-1.956-1.026H3.375A2.25 2.25 0 001.125 5.625v1.125z" /></svg>
                <span class="text-xs font-medium">Call Now</span>
            </a>
            <a href="#register" class="flex flex-col items-center justify-center p-3 text-center transition-colors hover:bg-white/10">
                <svg class="h-6 w-6 mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0h18M12 12.75h.008v.008H12v-.008z" /></svg>
                <span class="text-xs font-medium">Book Now</span>
            </a>
            <a href="https://wa.me/447988138221" target="_blank" class="flex flex-col items-center justify-center p-3 text-center transition-colors hover:bg-white/10">
                <svg class="h-6 w-6 mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8.625 9.75a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.125 1.125 0 01.792-.332h3.293a2.707 2.707 0 002.707-2.707V12.751c0-1.6-1.123-2.994-2.707-3.227A48.344 48.344 0 0012 9c-2.31 0-4.52.324-6.598.902-1.684.433-2.707 1.626-2.707 3.228z" /></svg>
                <span class="text-xs font-medium">WhatsApp</span>
            </a>
            <button class="menu-toggle-btn flex flex-col items-center justify-center p-3 text-center transition-colors hover:bg-white/10">
                <svg class="h-6 w-6 mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" /></svg>
                <span class="text-xs font-medium">Menu</span>
            </button>
        </div>
    </div>
    
    <div id="mobileMenu" class="md:hidden fixed inset-x-0 bottom-0 z-40 h-[calc(100%-60px)] w-full bg-white/95 backdrop-blur-lg transform translate-y-full transition-transform duration-300 ease-in-out">
        <div class="container mx-auto px-6 py-4 h-full overflow-y-auto pb-24">
            <ul class="grid gap-3">
                <li><a href="index.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Home</a></li>
           <li class="mobile-accordion">
    <button class="mobile-accordion-trigger w-full flex justify-between items-center px-3 py-2 rounded-md hover:bg-slate-100">
        <span class="font-semibold">About</span>
        <svg class="h-4 w-4 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
    </button>
    <div class="mobile-accordion-content pl-6 pt-2">
        <ul class="grid gap-1 text-slate-700">
            <li><a href="about.php" class="block py-1 hover:text-primary">About Us</a></li>
            <li><a href="team.php" class="block py-1 hover:text-primary">Our Team</a></li>
        </ul>
    </div>
</li>
               <li class="mobile-accordion">
                <button class="mobile-accordion-trigger w-full flex justify-between items-center px-3 py-2 rounded-md hover:bg-slate-100">
                    <span class="font-semibold">Services</span>
                    <svg class="h-4 w-4 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                </button>
                <div class="mobile-accordion-content pl-4 pt-2">
                    <ul class="grid gap-1 text-slate-700">
                        
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Sponsorship Licence</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Sponsor Licence Application</a></li><li><a href="#" class="block py-1 hover:text-primary">Sponsor Licence Renewal</a></li><li><a href="#" class="block py-1 hover:text-primary">Sponsor Licence Suspension</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Immigration Compliance</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Civil Penalty</a></li><li><a href="#" class="block py-1 hover:text-primary">HO Compliance Visit</a></li><li><a href="#" class="block py-1 hover:text-primary">Right to Work Check</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Skilled Worker Visas</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Skilled Worker Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Minister of Religion Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Health Care Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Temporary (Tier 5) Visas</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Religious Worker Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Creative Worker Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Charity Worker Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Partner and family Visas</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Spouse Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Dependent Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Unmarried Partner Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Global Business Mobility</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Graduate Trainee Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">UK Expansion Worker visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Specialist Worker Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Standard Visitor Visa</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Tourist Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Business Visit</a></li><li><a href="#" class="block py-1 hover:text-primary">UK Fiancé Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Study Visas</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Student Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Child Student Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Graduate Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Business Visas</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Self-Sponsorship in UK</a></li><li><a href="#" class="block py-1 hover:text-primary">Innovator Founder Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Turkish Businessperson Visa</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Scale Up Visa</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Scale-up Visa</a></li><li><a href="#" class="block py-1 hover:text-primary">Scale-up Sponsor Licence</a></li><li><a href="#" class="block py-1 hover:text-primary">Scale up Business</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>UKVI Compliant HR Software</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Compliant HR Software</a></li><li><a href="#" class="block py-1 hover:text-primary">Sponsorship Duties</a></li><li><a href="#" class="block py-1 hover:text-primary">HO Compliance Audit in UK</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>EU Settlement Scheme</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">EU Pre-Settled Status</a></li><li><a href="#" class="block py-1 hover:text-primary">EU Settled Status</a></li><li><a href="#" class="block py-1 hover:text-primary">EU Family Permit</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>UK Settlement Scheme</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">20 Year Private Life Route</a></li><li><a href="#" class="block py-1 hover:text-primary">ILR (5 year route)</a></li><li><a href="#" class="block py-1 hover:text-primary">ILR (10 year route)</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>British Citizenship</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Naturalisation</a></li><li><a href="#" class="block py-1 hover:text-primary">BNO Status</a></li><li><a href="#" class="block py-1 hover:text-primary">Registration</a></li></ul></div>
                        </li>
                        <li class="mobile-sub-accordion">
                            <button class="mobile-sub-accordion-trigger w-full flex justify-between items-center py-1 text-left font-medium"><span>Immigration Appeals</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button>
                            <div class="mobile-sub-accordion-content pl-4 pt-1"><ul class="text-sm space-y-1"><li><a href="#" class="block py-1 hover:text-primary">Judicial Review</a></li><li><a href="#" class="block py-1 hover:text-primary">Administrative Review</a></li><li><a href="#" class="block py-1 hover:text-primary">Appeal To The Tribunal</a></li></ul></div>
                        </li>

                         <li><a href="services.html" class="block py-1 mt-2 font-semibold text-primary">View All Services &rarr;</a></li>
                    </ul>
                </div>
            </li>
              <li><a href="psw.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">PSW</a></li>
              <li><a href="asylum.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Asylum</a></li>
              <li><a href="sponsor-checker.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Sponsor Checker</a></li>
              <li><a href="gallery.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Gallery</a></li>
              <li><a href="events.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Events</a></li>
              <li><a href="blog.php" class="block px-3 py-2 rounded-md hover:bg-slate-100">Blog</a></li>
              <li><a href="contact.php" class="block text-center px-3 py-2 rounded-md bg-primary text-white">Contact Us</a></li>
                </ul>
        </div>
    </div>
</header>